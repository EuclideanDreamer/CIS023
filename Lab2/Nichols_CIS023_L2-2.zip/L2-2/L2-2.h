/*
    Program Name: L2-2

    Author: Bailey Nichols

    Purpose: The purpose of the program is to deomonstrate the use of error checking. 

    Change log:
    10/06/2021       Bailey Nichols      1.0        Inital relesase 
 
*/     
#pragma once
#include <iostream>
#include <string>
#include <stdexcept>
#include "invalidSec.h"

using namespace std;
//