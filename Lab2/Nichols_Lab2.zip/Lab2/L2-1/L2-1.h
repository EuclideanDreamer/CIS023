/********************************************************************\
Program Name                L2-1

Programmer                    Bailey Nichols

Purpose of Program      This is an excercise given to first redefine the class rectangleType by declaring the
                                    instance variable as protected and then overload additional operators as defined in
                                    parts A through C as seen in notes. 


#==================#[ Change Log ]#=========================#
   Date                 Name             Version              Purpose
      |                         |                       |                         |
  00/00/0000    Bailey Nichols         00.00            Initial Release
*********************************************************************/
#include <iostream>
#include <fstream>
using namespace std;
class rectangleType
{
   friend ostream& operator <<(ostream&, const rectangleType &);
   friend istream& operator >>(istream&, rectangleType &);
private:
   /* data */
public:
   rectangleType(/* args */);
   ~rectangleType();
   double area()const;
   double getLength() const;
   double getWidth() const;
   double perimeter() const;
   void   setDimension(double l, double w);
   rectangleType operator + (const rectangleType &) const;    
   rectangleType operator - (const rectangleType &) const;    
   rectangleType operator * (const rectangleType&) const;    
   rectangleType operator ++ ();       
   rectangleType operator ++ (int);    
   rectangleType operator -- ();
   rectangleType operator -- (int);
   bool operator == (const rectangleType&) const;
   bool operator != (const rectangleType&) const;
   bool operator <= (const rectangleType&) const;
   bool operator < (const rectangleType&) const;
   bool operator >= (const rectangleType&) const;
   bool operator > (const rectangleType&) const;    
   rectangleType();    
   rectangleType(double l, double w);
};

rectangleType::rectangleType(/* args */)
{
}

rectangleType::~rectangleType()
{
   //
}

