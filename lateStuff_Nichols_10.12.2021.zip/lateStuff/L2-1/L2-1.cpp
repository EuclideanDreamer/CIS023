#include "rectangleType.h"

int main(){
    cout<<"Bailey Nichols\tL2-1\tL2-1.exe"<<endl;

    rectangleType a(2, 3), b(5, 8);

    if (a < b){
        printf("rectangle is big");
    } 

}