/********************************************************************\
Program Name                L2-1

Programmer                    Bailey Nichols

Purpose of Program      This is an excercise given to first redefine the class rectangleType by declaring the
                                    instance variable as protected and then overload additional operators as defined in
                                    parts A through C as seen in notes. 


#==================#[ Change Log ]#=========================#
   Date                 Name             Version              Purpose
      |                         |                       |                         |
  10/12/0000    Bailey Nichols         00.00            Initial Release
    
*********************************************************************/
#include <iostream>
#include <fstream>
using namespace std;
